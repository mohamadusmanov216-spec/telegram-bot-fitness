import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { realtimeMiddleware } from '@inngest/realtime/middleware';
import { serve, init } from '@mastra/inngest';
import { registerApiRoute as registerApiRoute$1 } from '@mastra/core/server';
import { createTool } from '@mastra/core/tools';
import * as fs from 'fs';
import * as path from 'path';

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

const {
  createWorkflow: originalCreateWorkflow,
  createStep} = init(inngest);
function createWorkflow(params) {
  return originalCreateWorkflow({
    ...params,
    retryConfig: {
      attempts: process.env.NODE_ENV === "production" ? 3 : 0,
      ...params.retryConfig ?? {}
    }
  });
}
const inngestFunctions = [];
function registerApiRoute(...args) {
  const [path, options] = args;
  if (typeof options !== "object") {
    return registerApiRoute$1(...args);
  }
  const pathWithoutSlash = path.replace(/^\/+/, "");
  const pathWithoutApi = pathWithoutSlash.startsWith("api/") ? pathWithoutSlash.substring(4) : pathWithoutSlash;
  const connectorName = pathWithoutApi.split("/")[0];
  inngestFunctions.push(
    inngest.createFunction(
      {
        id: `api-${connectorName}`,
        name: path
      },
      {
        // Match the event pattern created by createWebhook: event/api.webhooks.{connector-name}.action
        event: `event/api.webhooks.${connectorName}.action`
      },
      async ({ event, step }) => {
        await step.run("forward request to Mastra", async () => {
          const apiPath = path.startsWith("/api/") ? path : `/api${path}`;
          const response = await fetch(`http://localhost:5000${apiPath}`, {
            method: event.data.method,
            headers: event.data.headers,
            body: event.data.body
          });
          if (!response.ok) {
            if (response.status >= 500 && response.status < 600 || response.status == 429 || response.status == 408) {
              throw new Error(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            } else {
              throw new NonRetriableError(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            }
          }
        });
      }
    )
  );
  return registerApiRoute$1(...args);
}
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    mastra,
    inngest: inngest2,
    functions: inngestFunctions,
    registerOptions: { serveHost }
  });
}

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
if (!TELEGRAM_BOT_TOKEN) {
  throw new Error("TELEGRAM_BOT_TOKEN environment variable is not defined");
}
const TELEGRAM_API_URL = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;
const inlineKeyboardButtonSchema = z.object({
  text: z.string(),
  callback_data: z.string().optional(),
  url: z.string().optional()
});
const inlineKeyboardMarkupSchema = z.object({
  inline_keyboard: z.array(z.array(inlineKeyboardButtonSchema))
});
const telegramSendMessageTool = createTool({
  id: "telegram-send-message",
  description: "Send a message to a Telegram chat with optional inline keyboard",
  inputSchema: z.object({
    chat_id: z.union([z.string(), z.number()]).describe("The chat ID to send the message to"),
    text: z.string().describe("The message text to send"),
    parse_mode: z.enum(["Markdown", "HTML", "MarkdownV2"]).optional().describe("Parse mode for the message"),
    reply_markup: inlineKeyboardMarkupSchema.optional().describe("Inline keyboard markup")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message_id: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [telegramSendMessageTool] Sending message to chat:", { chat_id: context.chat_id });
    try {
      const response = await fetch(`${TELEGRAM_API_URL}/sendMessage`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: context.chat_id,
          text: context.text,
          parse_mode: context.parse_mode || "Markdown",
          reply_markup: context.reply_markup
        })
      });
      const data = await response.json();
      if (!response.ok) {
        logger?.error("\u274C [telegramSendMessageTool] Failed to send message:", data);
        return {
          success: false,
          error: data.description || "Failed to send message"
        };
      }
      logger?.info("\u2705 [telegramSendMessageTool] Message sent successfully");
      return {
        success: true,
        message_id: data.result?.message_id
      };
    } catch (error) {
      logger?.error("\u274C [telegramSendMessageTool] Error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
});
const telegramEditMessageTool = createTool({
  id: "telegram-edit-message",
  description: "Edit an existing Telegram message text and inline keyboard",
  inputSchema: z.object({
    chat_id: z.union([z.string(), z.number()]).describe("The chat ID"),
    message_id: z.number().describe("The message ID to edit"),
    text: z.string().describe("The new message text"),
    parse_mode: z.enum(["Markdown", "HTML", "MarkdownV2"]).optional().describe("Parse mode for the message"),
    reply_markup: inlineKeyboardMarkupSchema.optional().describe("Inline keyboard markup")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [telegramEditMessageTool] Editing message:", {
      chat_id: context.chat_id,
      message_id: context.message_id
    });
    try {
      const response = await fetch(`${TELEGRAM_API_URL}/editMessageText`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: context.chat_id,
          message_id: context.message_id,
          text: context.text,
          parse_mode: context.parse_mode || "Markdown",
          reply_markup: context.reply_markup
        })
      });
      const data = await response.json();
      if (!response.ok) {
        logger?.error("\u274C [telegramEditMessageTool] Failed to edit message:", data);
        return {
          success: false,
          error: data.description || "Failed to edit message"
        };
      }
      logger?.info("\u2705 [telegramEditMessageTool] Message edited successfully");
      return {
        success: true
      };
    } catch (error) {
      logger?.error("\u274C [telegramEditMessageTool] Error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
});
const telegramAnswerCallbackQueryTool = createTool({
  id: "telegram-answer-callback-query",
  description: "Answer a callback query to remove loading state from button",
  inputSchema: z.object({
    callback_query_id: z.string().describe("Callback query ID to answer"),
    text: z.string().optional().describe("Optional notification text to show"),
    show_alert: z.boolean().optional().describe("Show as alert instead of notification")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [telegramAnswerCallbackQueryTool] Answering callback query");
    try {
      const response = await fetch(`${TELEGRAM_API_URL}/answerCallbackQuery`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          callback_query_id: context.callback_query_id,
          text: context.text,
          show_alert: context.show_alert || false
        })
      });
      const data = await response.json();
      if (!response.ok) {
        logger?.error("\u274C [telegramAnswerCallbackQueryTool] Failed to answer callback:", data);
        return {
          success: false,
          error: data.description || "Failed to answer callback query"
        };
      }
      logger?.info("\u2705 [telegramAnswerCallbackQueryTool] Callback answered successfully");
      return {
        success: true
      };
    } catch (error) {
      logger?.error("\u274C [telegramAnswerCallbackQueryTool] Error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
});
createTool({
  id: "telegram-send-photo",
  description: "Send a photo to a Telegram chat with optional caption and inline keyboard",
  inputSchema: z.object({
    chat_id: z.union([z.string(), z.number()]).describe("The chat ID to send the photo to"),
    photo: z.string().describe("Photo file_id or URL"),
    caption: z.string().optional().describe("Photo caption"),
    parse_mode: z.enum(["Markdown", "HTML", "MarkdownV2"]).optional().describe("Parse mode for the caption"),
    reply_markup: inlineKeyboardMarkupSchema.optional().describe("Inline keyboard markup")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message_id: z.number().optional(),
    file_id: z.string().optional().describe("File ID of the sent photo for reuse"),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [telegramSendPhotoTool] Sending photo to chat:", { chat_id: context.chat_id });
    try {
      const response = await fetch(`${TELEGRAM_API_URL}/sendPhoto`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: context.chat_id,
          photo: context.photo,
          caption: context.caption,
          parse_mode: context.parse_mode || "Markdown",
          reply_markup: context.reply_markup
        })
      });
      const data = await response.json();
      if (!response.ok) {
        logger?.error("\u274C [telegramSendPhotoTool] Failed to send photo:", data);
        return {
          success: false,
          error: data.description || "Failed to send photo"
        };
      }
      logger?.info("\u2705 [telegramSendPhotoTool] Photo sent successfully");
      return {
        success: true,
        message_id: data.result?.message_id,
        file_id: data.result?.photo?.[0]?.file_id
      };
    } catch (error) {
      logger?.error("\u274C [telegramSendPhotoTool] Error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
});
const telegramDeleteMessageTool = createTool({
  id: "telegram-delete-message",
  description: "Delete a message from a Telegram chat",
  inputSchema: z.object({
    chat_id: z.union([z.string(), z.number()]).describe("The chat ID"),
    message_id: z.number().describe("The message ID to delete")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [telegramDeleteMessageTool] Deleting message:", {
      chat_id: context.chat_id,
      message_id: context.message_id
    });
    try {
      const response = await fetch(`${TELEGRAM_API_URL}/deleteMessage`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: context.chat_id,
          message_id: context.message_id
        })
      });
      const data = await response.json();
      if (!response.ok) {
        logger?.error("\u274C [telegramDeleteMessageTool] Failed to delete message:", data);
        return {
          success: false,
          error: data.description || "Failed to delete message"
        };
      }
      logger?.info("\u2705 [telegramDeleteMessageTool] Message deleted successfully");
      return {
        success: true
      };
    } catch (error) {
      logger?.error("\u274C [telegramDeleteMessageTool] Error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
});

const STORAGE_PATH = path.join(process.cwd(), "data", "applications.json");
function ensureStorageFile() {
  const dir = path.dirname(STORAGE_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(STORAGE_PATH)) {
    fs.writeFileSync(STORAGE_PATH, "{}", "utf8");
  }
}
function readStorage() {
  ensureStorageFile();
  const data = fs.readFileSync(STORAGE_PATH, "utf8");
  return JSON.parse(data) || {};
}
function writeStorage(data) {
  ensureStorageFile();
  fs.writeFileSync(STORAGE_PATH, JSON.stringify(data, null, 2), "utf8");
}
function getApplication(chatId) {
  const storage = readStorage();
  return storage[chatId] || null;
}
function setApplication(chatId, app) {
  const storage = readStorage();
  storage[chatId] = { chatId, ...app };
  writeStorage(storage);
}
function deleteApplication(chatId) {
  const storage = readStorage();
  delete storage[chatId];
  writeStorage(storage);
}
function hasApplication(chatId) {
  const storage = readStorage();
  return chatId in storage;
}
function getAllApplications() {
  return readStorage();
}
function clearAllApplications() {
  writeStorage({});
}

const ADMIN_ID = "1061591635";
const MAIN_MENU_TEXT$1 = `\u042F \u0437\u043D\u0430\u044E , \u0447\u0442\u043E \u0442\u044B \u0445\u043E\u0447\u0435\u0448\u044C \u0441\u0435\u0431\u0435 \u0445\u043E\u0440\u043E\u0448\u0443\u044E \u0444\u043E\u0440\u043C\u0443, \u0437\u043D\u0430\u044E , \u0447\u0442\u043E \u0432 \u0444\u0443\u0442\u0431\u043E\u043B\u043A\u0435 \u0438\u043B\u0438 \u0432 \u043A\u043E\u0444\u0442\u0435 \u0442\u044B \u0445\u043E\u0447\u0435\u0448\u044C \u0431\u044B\u0442\u044C \u0432 \u0446\u0435\u043D\u0442\u0440\u0435 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F \u0441\u0440\u0435\u0434\u0438 \u0432\u0441\u0435\u0445\u{1F60E}

\u0427\u0442\u043E \u0442\u044B \u043C\u043E\u0436\u0435\u0448\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C:
1\uFE0F\u20E3\u041A\u0430\u043A \u043D\u0430\u0431\u0440\u0430\u0442\u044C \u043C\u044B\u0448\u0435\u0447\u043D\u0443\u044E \u043C\u0430\u0441\u0441\u0443\u{1F4AA}
2\uFE0F\u20E3\u041A\u0430\u043A \u0438\u0437\u0431\u0430\u0432\u0438\u0442\u044C\u0441\u044F \u043E\u0442 \u043B\u0438\u0448\u043D\u0435\u0433\u043E \u0432\u0435\u0441\u0430\u{1F525}
3\uFE0F\u20E3\u041A\u0430\u043A \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u043F\u043E\u0434 \u0441\u0435\u0431\u044F \u043A\u0443\u0440\u0441\u{1F51D}
4\uFE0F\u20E3\u0418 \u043A\u043E\u043D\u0435\u0447\u043D\u043E \u0436\u0435 \u043F\u0440\u043E \xAB\u0427\u0435\u0440\u043D\u044B\u0439 \u0440\u044B\u043D\u043E\u043A\xBB\u{1F608}

\u041F\u0440\u0438\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u0441\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430 \u0438\u0437 \u0442\u0440\u0435\u0445 \u0431\u0443\u043A\u0432\u044B \xAB\u041D\u041D\u041D\xBB(\u041D\u0435\u0442 \u041D\u0438\u0447\u0435\u0433\u043E \u041D\u0435\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0433\u043E) \u0438 \u0442\u043E\u043F\u0438\u043C \u0434\u0430\u043B\u044C\u0448\u0435 \u{1F680}`;
const processTelegramMessage = createStep({
  id: "process-telegram-message",
  description: "Process incoming Telegram message or callback query",
  inputSchema: z.object({
    threadId: z.string().describe("Unique thread ID for this conversation"),
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID"),
    messageId: z.number().optional().describe("Message ID for editing"),
    messageText: z.string().optional().describe("Text of the message"),
    callbackData: z.string().optional().describe("Callback data from button press"),
    callbackQueryId: z.string().optional().describe("Callback query ID for answering"),
    userName: z.string().optional().describe("Username of the sender")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    action: z.string()
  }),
  execute: async ({ inputData, mastra, runtimeContext }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F680} [FitnessBot] Processing message", {
      chatId: inputData.chatId,
      hasCallback: !!inputData.callbackData,
      hasText: !!inputData.messageText
    });
    const { chatId, messageText, callbackData, messageId, userName, callbackQueryId } = inputData;
    if (messageText === "/start") {
      logger?.info("\u{1F4E4} [FitnessBot] Sending welcome message");
      await telegramSendMessageTool.execute({
        context: {
          chat_id: chatId,
          text: MAIN_MENU_TEXT$1,
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "\u{1F4AA} \u041F\u0440\u043E \u0441\u043F\u043E\u0440\u0442 \u043F\u0438\u0442\u0430\u043D\u0438\u0435", callback_data: "nutrition_video" }
              ],
              [
                { text: "\u{1F3C6} \u041F\u043E\u0434 \u043A\u043B\u044E\u0447 \u0441 \u0418\u0441\u043B\u0430\u043C\u043E\u043C", callback_data: "coaching_video" }
              ]
            ]
          }
        },
        mastra,
        runtimeContext
      });
      return { success: true, action: "start_sent" };
    }
    if (hasApplication(chatId.toString()) && messageText && !callbackData) {
      logger?.info("\u{1F4DD} [FitnessBot] Processing application answer");
      const userApp = getApplication(chatId.toString());
      if (!userApp) {
        logger?.error("\u274C [FitnessBot] Application not found for chatId:", chatId);
        return { success: false, action: "application_error" };
      }
      const answer = messageText;
      const questions = [
        `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 2/6:

\u0420\u043E\u0441\u0442 \u0438 \u0432\u0435\u0441?

*\u041F\u0440\u0438\u043C\u0435\u0440:* 180 \u0441\u043C 75 \u043A\u0433`,
        `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 3/6:

\u0423 \u0442\u0435\u0431\u044F \u0435\u0441\u0442\u044C \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F, \u0442\u0440\u0430\u0432\u043C\u044B, \u0430\u043B\u043B\u0435\u0440\u0433\u0438\u0438 \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u043D\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438?

*\u0415\u0441\u043B\u0438 \u043D\u0435\u0442, \u043D\u0430\u043F\u0438\u0448\u0438 "\u041D\u0435\u0442"*`,
        `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 4/6:

\u0423 \u0442\u0435\u0431\u044F \u0435\u0441\u0442\u044C \u0446\u0435\u043B\u0438 \u0438 \u0437\u0430\u0434\u0430\u0447\u0438 \u043D\u0430 \u0442\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u043E\u0447\u043D\u044B\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441?

*\u041F\u0440\u0438\u043C\u0435\u0440:* \u043D\u0430\u0431\u043E\u0440 \u043C\u0430\u0441\u0441\u044B, \u0441\u043A\u0438\u043D\u0443\u0442\u044C \u0432\u0435\u0441, \u0440\u0435\u043B\u044C\u0435\u0444`,
        `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 5/6:

\u041F\u043B\u0430\u043D\u0438\u0440\u0443\u0435\u0442\u0435 \u043B\u0438 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C \u0444\u0430\u0440\u043C\u0430\u043A\u043E\u043B\u043E\u0433\u0438\u044E, SARMS?

*\u0414\u0430/\u041D\u0435\u0442*`,
        `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 6/6:

\u0415\u0441\u043B\u0438 \u0434\u0430, \u0442\u043E \u043A\u0430\u043A\u0438\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u044B \u0438 \u0434\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0438?

*\u0415\u0441\u043B\u0438 \u043D\u0435\u0442, \u043D\u0430\u043F\u0438\u0448\u0438 "\u041D\u0435\u0442"*`
      ];
      const answerKeys = ["nameAge", "heightWeight", "health", "goals", "plansPharmacology", "currentPharmacology"];
      if (userApp.step <= 5) {
        userApp.answers[answerKeys[userApp.step - 1]] = answer;
        userApp.step++;
        const result = await telegramSendMessageTool.execute({
          context: {
            chat_id: chatId,
            text: questions[userApp.step - 2],
            parse_mode: "Markdown",
            reply_markup: {
              inline_keyboard: [
                [{ text: "\u274C \u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443", callback_data: "cancel_application" }]
              ]
            }
          },
          runtimeContext
        });
        const messageIds = userApp.messageIds || [];
        if (result.message_id) {
          messageIds.push(result.message_id);
        }
        setApplication(chatId.toString(), {
          step: userApp.step,
          answers: userApp.answers,
          createdAt: userApp.createdAt,
          messageIds
        });
      } else {
        userApp.answers.currentPharmacology = answer;
        const applicationText = `\u{1F3AF} *\u041D\u041E\u0412\u0410\u042F \u0417\u0410\u042F\u0412\u041A\u0410 \u041D\u0410 \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041A\u0418*

\u{1F464} *\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F:*
\u2022 \u0418\u043C\u044F \u0438 \u0432\u043E\u0437\u0440\u0430\u0441\u0442: ${userApp.answers.nameAge || "\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"}
\u2022 \u0420\u043E\u0441\u0442 \u0438 \u0432\u0435\u0441: ${userApp.answers.heightWeight || "\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"}

\u{1F3E5} *\u0417\u0434\u043E\u0440\u043E\u0432\u044C\u0435:*
\u2022 \u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435: ${userApp.answers.health || "\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"}

\u{1F3AF} *\u0426\u0435\u043B\u0438 \u0442\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u043E\u043A:*
\u2022 \u0417\u0430\u0434\u0430\u0447\u0438: ${userApp.answers.goals || "\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"}

\u{1F48A} *\u0424\u0430\u0440\u043C\u0430\u043A\u043E\u043B\u043E\u0433\u0438\u044F:*
\u2022 \u041F\u043B\u0430\u043D\u044B: ${userApp.answers.plansPharmacology || "\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"}
\u2022 \u0422\u0435\u043A\u0443\u0449\u0430\u044F: ${userApp.answers.currentPharmacology || "\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"}

\u{1F4F1} *\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435:*
\u2022 \u041E\u0442: @${userName || "\u0431\u0435\u0437 username"}
\u2022 ID: ${chatId}
\u2022 \u0412\u0440\u0435\u043C\u044F: ${(/* @__PURE__ */ new Date()).toLocaleString("ru-RU")}`;
        logger?.info("\u{1F4E8} [FitnessBot] Sending application to admin");
        await telegramSendMessageTool.execute({
          context: {
            chat_id: ADMIN_ID,
            text: applicationText,
            parse_mode: "Markdown"
          },
          runtimeContext
        });
        const messageIds = userApp.messageIds || [];
        const confirmResult = await telegramSendMessageTool.execute({
          context: {
            chat_id: chatId,
            text: `\u2705 *\u0417\u0410\u042F\u0412\u041A\u0410 \u041F\u0420\u0418\u041D\u042F\u0422\u0410!* \u{1F389}

\u0421\u043F\u0430\u0441\u0438\u0431\u043E \u0437\u0430 \u0432\u0430\u0448\u0443 \u0437\u0430\u044F\u0432\u043A\u0443! \u{1F64F} \u042F \u0441\u0432\u044F\u0436\u0443\u0441\u044C \u0441 \u0432\u0430\u043C\u0438 \u0432 \u0431\u043B\u0438\u0436\u0430\u0439\u0448\u0435\u0435 \u0432\u0440\u0435\u043C\u044F.

\u{1F48E} *\u0411\u041E\u041D\u0423\u0421:* \u041D\u0430\u043F\u0438\u0448\u0438 \xAB\u041A\u043E\u0443\u0447\xBB \u043D\u0430 Wa.me/79222220217 \u0438 \u043F\u043E\u043B\u0443\u0447\u0438 20% \u0421\u041A\u0418\u0414\u041A\u0423! \u{1F525}`,
            parse_mode: "Markdown",
            reply_markup: {
              inline_keyboard: [
                [{ text: "\u{1F3E0} \u0413\u043B\u0430\u0432\u043D\u043E\u0435 \u043C\u0435\u043D\u044E", callback_data: "main_menu" }],
                [{ text: "\u{1F5D1} \u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0447\u0430\u0442", callback_data: "clear_chat" }]
              ]
            }
          },
          runtimeContext
        });
        if (confirmResult.message_id) {
          messageIds.push(confirmResult.message_id);
        }
        setApplication(chatId.toString(), {
          step: 999,
          answers: {},
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          messageIds
        });
        logger?.info("\u{1F4BE} [FitnessBot] Saved message IDs for cleanup", { count: messageIds.length });
      }
      return { success: true, action: "application_processed" };
    }
    if (callbackData && messageId) {
      logger?.info("\u{1F518} [FitnessBot] Processing callback", { callback: callbackData });
      if (callbackQueryId) {
        await telegramAnswerCallbackQueryTool.execute({
          context: {
            callback_query_id: callbackQueryId
          },
          runtimeContext
        });
      }
      switch (callbackData) {
        case "start_application":
          const editResult = await telegramEditMessageTool.execute({
            context: {
              chat_id: chatId,
              message_id: messageId,
              text: `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 1/6:

\u0412\u0430\u0448\u0435 \u0438\u043C\u044F \u0438 \u0432\u043E\u0437\u0440\u0430\u0441\u0442?

*\u041F\u0440\u0438\u043C\u0435\u0440:* \u0410\u0445\u043C\u0430\u0434 21`,
              parse_mode: "Markdown",
              reply_markup: {
                inline_keyboard: [
                  [{ text: "\u274C \u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443", callback_data: "cancel_application" }]
                ]
              }
            },
            runtimeContext
          });
          const initialMessageIds = [];
          if (editResult.message_id) {
            initialMessageIds.push(editResult.message_id);
          } else if (messageId) {
            initialMessageIds.push(messageId);
          }
          setApplication(chatId.toString(), {
            step: 1,
            answers: {},
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            messageIds: initialMessageIds
          });
          break;
        case "clear_chat":
          const userAppData = getApplication(chatId.toString());
          if (userAppData && userAppData.messageIds && userAppData.messageIds.length > 0) {
            logger?.info("\u{1F5D1} [FitnessBot] Clearing chat messages", { count: userAppData.messageIds.length });
            for (const msgId of userAppData.messageIds) {
              try {
                await telegramDeleteMessageTool.execute({
                  context: {
                    chat_id: chatId,
                    message_id: msgId
                  },
                  runtimeContext
                });
              } catch (error) {
                logger?.warn("\u26A0\uFE0F [FitnessBot] Failed to delete message", { message_id: msgId });
              }
            }
            deleteApplication(chatId.toString());
            logger?.info("\u2705 [FitnessBot] Chat cleared successfully");
          }
          await telegramEditMessageTool.execute({
            context: {
              chat_id: chatId,
              message_id: messageId,
              text: `\u2705 *\u0427\u0410\u0422 \u041E\u0427\u0418\u0429\u0415\u041D!*

\u0412\u0441\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u0430\u043D\u043A\u0435\u0442\u044B \u0443\u0434\u0430\u043B\u0435\u043D\u044B. \u0413\u043E\u0442\u043E\u0432\u044B \u043D\u0430\u0447\u0430\u0442\u044C \u0437\u0430\u043D\u043E\u0432\u043E?`,
              parse_mode: "Markdown",
              reply_markup: {
                inline_keyboard: [
                  [{ text: "\u{1F3E0} \u0413\u043B\u0430\u0432\u043D\u043E\u0435 \u043C\u0435\u043D\u044E", callback_data: "main_menu" }]
                ]
              }
            },
            runtimeContext
          });
          break;
        case "cancel_application":
          deleteApplication(chatId.toString());
          await telegramEditMessageTool.execute({
            context: {
              chat_id: chatId,
              message_id: messageId,
              text: `\u274C *\u0417\u0410\u042F\u0412\u041A\u0410 \u041E\u0422\u041C\u0415\u041D\u0415\u041D\u0410*

\u0412\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0439\u0442\u0435\u0441\u044C, \u043A\u043E\u0433\u0434\u0430 \u0431\u0443\u0434\u0435\u0442\u0435 \u0433\u043E\u0442\u043E\u0432\u044B \u043D\u0430\u0447\u0430\u0442\u044C \u0442\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u043A\u0438!`,
              parse_mode: "Markdown",
              reply_markup: {
                inline_keyboard: [
                  [{ text: "\u{1F3E0} \u0413\u043B\u0430\u0432\u043D\u043E\u0435 \u043C\u0435\u043D\u044E", callback_data: "main_menu" }]
                ]
              }
            },
            runtimeContext
          });
          break;
      }
      return { success: true, action: `callback_${callbackData}` };
    }
    logger?.info("\u{1F4AC} [FitnessBot] User sent text outside application - returning to main menu");
    await telegramSendMessageTool.execute({
      context: {
        chat_id: chatId,
        text: MAIN_MENU_TEXT$1,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "\u{1F4AA} \u041F\u0440\u043E \u0441\u043F\u043E\u0440\u0442 \u043F\u0438\u0442\u0430\u043D\u0438\u0435", callback_data: "nutrition_video" }],
            [{ text: "\u{1F3C6} \u041F\u043E\u0434 \u043A\u043B\u044E\u0447 \u0441 \u0418\u0441\u043B\u0430\u043C\u043E\u043C", callback_data: "coaching_video" }]
          ]
        }
      },
      runtimeContext
    });
    return { success: true, action: "menu_sent" };
  }
});
const logResults = createStep({
  id: "log-results",
  description: "Log the results of the fitness bot interaction",
  inputSchema: z.object({
    success: z.boolean(),
    action: z.string()
  }),
  outputSchema: z.object({
    completed: z.boolean(),
    summary: z.string()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u2705 [FitnessBot] Workflow completed", { action: inputData.action });
    return {
      completed: true,
      summary: `Fitness bot handled action: ${inputData.action}`
    };
  }
});
const fitnessWorkflow = createWorkflow({
  id: "fitness-bot-workflow",
  inputSchema: z.object({
    threadId: z.string().describe("Unique thread ID for this conversation"),
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID"),
    messageId: z.number().optional().describe("Message ID for editing"),
    messageText: z.string().optional().describe("Text of the message"),
    callbackData: z.string().optional().describe("Callback data from button press"),
    userName: z.string().optional().describe("Username of the sender")
  }),
  outputSchema: z.object({
    completed: z.boolean(),
    summary: z.string()
  })
}).then(processTelegramMessage).then(logResults).commit();

const NUTRITION_VIDEO_TEXT = `\u{1F4AA} \u0421\u041F\u041E\u0420\u0422 \u041F\u0418\u0422\u0410\u041D\u0418\u0415 - \u043C\u043E\u0439 \u0443\u0441\u043F\u0435\u0445 \u{1F64C}\u{1F3FB}

\u{1F4F9} \u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0432\u0438\u0434\u0435\u043E: 
https://www.youtube.com/watch?v=ct3l0gPaVQI

\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u0432\u0438\u0434\u0435\u043E \u0442\u044B:
\u{1F447}\u{1F3FB} \u0423\u0437\u043D\u0430\u0435\u0448\u044C \u043A\u0430\u043A \u043D\u0430\u0431\u0440\u0430\u0442\u044C \u043C\u0430\u0441\u0441\u0443 
\u{1F447}\u{1F3FB} \u041A\u0430\u043A \u0441\u043A\u0438\u043D\u0443\u0442\u044C \u043B\u0438\u0448\u043D\u0438\u0439 \u0432\u0435\u0441 
\u{1F447}\u{1F3FB} \u041A\u0430\u043A \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u043F\u0438\u0442\u044C \u0438 \u0447\u0442\u043E \u0443\u043F\u043E\u0442\u0440\u0435\u0431\u043B\u044F\u0442\u044C \u0432 \u0440\u0430\u0437\u043D\u044B\u0445 \u0441\u043B\u0443\u0447\u0430\u044F\u0445
\u{1F447}\u{1F3FB} \u041A\u0430\u043A \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u043A\u0443\u0440\u0441\u0438\u0442\u044C 

\u{1F381} \u0422\u0412\u041E\u0419 \u0411\u041E\u041D\u0423\u0421: 20% \u0421\u041A\u0418\u0414\u041A\u0410 \u{1F64C}\u{1F3FB}

\u041D\u0430\u043F\u0438\u0448\u0438 \u043C\u043D\u0435 \xAB\u041A\u043E\u0443\u0447\xBB \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u044F \u043D\u0430 \u0432\u0430\u0442\u0441\u0430\u043F\u043F 
Wa.me/79222220217`;
const COACHING_VIDEO_TEXT = `\u{1F3C6}\u041F\u043E\u0447\u0435\u043C\u0443 \u0442\u044B \u0434\u043E\u043B\u0436\u0435\u043D \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0441\u0435\u0431\u0435 \u0443\u0441\u043B\u0443\u0433\u0443 \xAB\u041F\u043E\u0434 \u043A\u043B\u044E\u0447 \u0441 \u0418\u0441\u043B\u0430\u043C\u043E\u043C\xBB? \u0414\u043E\u0441\u043C\u043E\u0442\u0440\u0438 \u044D\u0442\u043E \u0432\u0438\u0434\u0435\u043E\u{1F447}\u{1F3FB}

\u{1F4F9}\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0432\u0438\u0434\u0435\u043E:
https://www.youtube.com/watch?v=Z38azV8aDzI

\u{1F4F2} Wa.me/79252159494
\u041D\u0430\u043F\u0438\u0448\u0438 \xAB\u041A\u043E\u0443\u0447\xBB \u043C\u043D\u0435 \u043D\u0430 \u0432\u0430\u0442\u0441\u0430\u043F\u043F\u{1F446}\u{1F3FB} \u0438 \u043F\u043E\u043B\u0443\u0447\u0438 20% \u0441\u043A\u0438\u0434\u043A\u0443 \u043D\u0430 \u0441\u043F\u043E\u0440\u0442 \u043F\u0438\u0442\u{1F381}`;
const MAIN_MENU_TEXT = `\u042F \u0437\u043D\u0430\u044E , \u0447\u0442\u043E \u0442\u044B \u0445\u043E\u0447\u0435\u0448\u044C \u0441\u0435\u0431\u0435 \u0445\u043E\u0440\u043E\u0448\u0443\u044E \u0444\u043E\u0440\u043C\u0443, \u0437\u043D\u0430\u044E , \u0447\u0442\u043E \u0432 \u0444\u0443\u0442\u0431\u043E\u043B\u043A\u0435 \u0438\u043B\u0438 \u0432 \u043A\u043E\u0444\u0442\u0435 \u0442\u044B \u0445\u043E\u0447\u0435\u0448\u044C \u0431\u044B\u0442\u044C \u0432 \u0446\u0435\u043D\u0442\u0440\u0435 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F \u0441\u0440\u0435\u0434\u0438 \u0432\u0441\u0435\u0445\u{1F60E}

\u0427\u0442\u043E \u0442\u044B \u043C\u043E\u0436\u0435\u0448\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C:
1\uFE0F\u20E3\u041A\u0430\u043A \u043D\u0430\u0431\u0440\u0430\u0442\u044C \u043C\u044B\u0448\u0435\u0447\u043D\u0443\u044E \u043C\u0430\u0441\u0441\u0443\u{1F4AA}
2\uFE0F\u20E3\u041A\u0430\u043A \u0438\u0437\u0431\u0430\u0432\u0438\u0442\u044C\u0441\u044F \u043E\u0442 \u043B\u0438\u0448\u043D\u0435\u0433\u043E \u0432\u0435\u0441\u0430\u{1F525}
3\uFE0F\u20E3\u041A\u0430\u043A \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u043F\u043E\u0434 \u0441\u0435\u0431\u044F \u043A\u0443\u0440\u0441\u{1F51D}
4\uFE0F\u20E3\u0418 \u043A\u043E\u043D\u0435\u0447\u043D\u043E \u0436\u0435 \u043F\u0440\u043E \xAB\u0427\u0435\u0440\u043D\u044B\u0439 \u0440\u044B\u043D\u043E\u043A\xBB\u{1F608}

\u041F\u0440\u0438\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u0441\u044F \u043F\u0440\u0430\u0432\u0438\u043B\u0430 \u0438\u0437 \u0442\u0440\u0435\u0445 \u0431\u0443\u043A\u0432\u044B \xAB\u041D\u041D\u041D\xBB(\u041D\u0435\u0442 \u041D\u0438\u0447\u0435\u0433\u043E \u041D\u0435\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0433\u043E) \u0438 \u0442\u043E\u043F\u0438\u043C \u0434\u0430\u043B\u044C\u0448\u0435 \u{1F680}`;
function registerTelegramTrigger({
  triggerType,
  handler
}) {
  return [
    registerApiRoute("/webhooks/telegram/action", {
      method: "POST",
      handler: async (c) => {
        const mastra = c.get("mastra");
        const logger = mastra.getLogger();
        try {
          const payload = await c.req.json();
          logger?.info("\u{1F4DD} [Telegram] Received webhook payload", {
            hasMessage: !!payload.message,
            hasCallbackQuery: !!payload.callback_query
          });
          let triggerInfo;
          if (payload.callback_query) {
            const callbackData = payload.callback_query.data;
            const chatId = payload.callback_query.message?.chat.id;
            const messageId = payload.callback_query.message?.message_id;
            const callbackQueryId = payload.callback_query.id;
            const simpleNavigationCallbacks = ["nutrition_video", "coaching_video", "main_menu"];
            if (simpleNavigationCallbacks.includes(callbackData)) {
              logger?.info("\u26A1 [Telegram] Fast-path callback", { callback: callbackData });
              let text = "";
              let replyMarkup;
              switch (callbackData) {
                case "nutrition_video":
                  text = NUTRITION_VIDEO_TEXT;
                  replyMarkup = {
                    inline_keyboard: [
                      [{ text: "\u{1F3C6} \u041F\u043E\u0434 \u043A\u043B\u044E\u0447 \u0441 \u0418\u0441\u043B\u0430\u043C\u043E\u043C", callback_data: "coaching_video" }],
                      [{ text: "\u{1F4CB} \u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443", callback_data: "start_application" }]
                    ]
                  };
                  break;
                case "coaching_video":
                  text = COACHING_VIDEO_TEXT;
                  replyMarkup = {
                    inline_keyboard: [
                      [{ text: "\u{1F4AA} \u041F\u0440\u043E \u0441\u043F\u043E\u0440\u0442 \u043F\u0438\u0442\u0430\u043D\u0438\u0435", callback_data: "nutrition_video" }],
                      [{ text: "\u{1F4CB} \u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443", callback_data: "start_application" }]
                    ]
                  };
                  break;
                case "main_menu":
                  text = MAIN_MENU_TEXT;
                  replyMarkup = {
                    inline_keyboard: [
                      [{ text: "\u{1F4AA} \u041F\u0440\u043E \u0441\u043F\u043E\u0440\u0442 \u043F\u0438\u0442\u0430\u043D\u0438\u0435", callback_data: "nutrition_video" }],
                      [{ text: "\u{1F3C6} \u041F\u043E\u0434 \u043A\u043B\u044E\u0447 \u0441 \u0418\u0441\u043B\u0430\u043C\u043E\u043C", callback_data: "coaching_video" }],
                      [{ text: "\u{1F4CB} \u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443", callback_data: "start_application" }]
                    ]
                  };
                  break;
              }
              telegramAnswerCallbackQueryTool.execute({
                context: { callback_query_id: callbackQueryId },
                mastra,
                runtimeContext: {}
              }).catch((err) => logger?.error("\u274C [Telegram] Failed to answer callback:", err));
              telegramEditMessageTool.execute({
                context: {
                  chat_id: chatId,
                  message_id: messageId,
                  text,
                  parse_mode: "Markdown",
                  reply_markup: replyMarkup
                },
                mastra,
                runtimeContext: {}
              }).catch((err) => logger?.error("\u274C [Telegram] Failed to edit message:", err));
              logger?.info("\u2705 [Telegram] Fast-path initiated");
              return c.text("OK", 200);
            }
            triggerInfo = {
              type: "telegram/message",
              params: {
                userName: payload.callback_query.from?.username || "unknown",
                message: payload.callback_query.data || "",
                chatId: payload.callback_query.message?.chat.id,
                messageId: payload.callback_query.message?.message_id,
                callbackData: payload.callback_query.data,
                callbackQueryId: payload.callback_query.id
              },
              payload
            };
          } else if (payload.message) {
            const chatId = payload.message.chat.id;
            const messageText = payload.message.text || "";
            const ADMIN_ID = 1061591635;
            if (chatId === ADMIN_ID && (messageText === "/admin" || messageText === "/clear")) {
              logger?.info("\u{1F510} [Telegram] Admin command received", { command: messageText });
              if (messageText === "/admin") {
                const allApps = getAllApplications();
                const appCount = Object.keys(allApps).length;
                let responseText = `\u{1F510} *\u0410\u0414\u041C\u0418\u041D \u041F\u0410\u041D\u0415\u041B\u042C*

\u{1F4CA} \u0412\u0441\u0435\u0433\u043E \u0437\u0430\u044F\u0432\u043E\u043A: ${appCount}

`;
                if (appCount === 0) {
                  responseText += "\u274C \u041D\u0435\u0442 \u0437\u0430\u044F\u0432\u043E\u043A";
                } else {
                  responseText += "\u{1F4DD} *\u0421\u041F\u0418\u0421\u041E\u041A \u0417\u0410\u042F\u0412\u041E\u041A:*\n\n";
                  let counter = 1;
                  for (const [chatId2, app] of Object.entries(allApps)) {
                    responseText += `${counter}. \u{1F464} ID: \`${chatId2}\`
`;
                    responseText += `   \u{1F4C5} \u0414\u0430\u0442\u0430: ${new Date(app.createdAt).toLocaleString("ru-RU")}
`;
                    responseText += `   \u{1F4CA} \u0428\u0430\u0433: ${app.step}
`;
                    if (app.answers && Object.keys(app.answers).length > 0) {
                      responseText += `   \u2705 \u041E\u0442\u0432\u0435\u0442\u044B:
`;
                      if (app.answers.nameAge) responseText += `      \u2022 \u0418\u043C\u044F/\u0412\u043E\u0437\u0440\u0430\u0441\u0442: ${app.answers.nameAge}
`;
                      if (app.answers.heightWeight) responseText += `      \u2022 \u0420\u043E\u0441\u0442/\u0412\u0435\u0441: ${app.answers.heightWeight}
`;
                      if (app.answers.health) responseText += `      \u2022 \u0417\u0434\u043E\u0440\u043E\u0432\u044C\u0435: ${app.answers.health}
`;
                      if (app.answers.goals) responseText += `      \u2022 \u0426\u0435\u043B\u0438: ${app.answers.goals}
`;
                      if (app.answers.plansPharmacology) responseText += `      \u2022 \u041F\u043B\u0430\u043D \u0444\u0430\u0440\u043C\u0430: ${app.answers.plansPharmacology}
`;
                      if (app.answers.currentPharmacology) responseText += `      \u2022 \u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u0444\u0430\u0440\u043C\u0430: ${app.answers.currentPharmacology}
`;
                    }
                    responseText += "\n";
                    counter++;
                  }
                }
                telegramSendMessageTool.execute({
                  context: {
                    chat_id: chatId,
                    text: responseText,
                    parse_mode: "Markdown"
                  },
                  mastra,
                  runtimeContext: {}
                }).catch((err) => logger?.error("\u274C [Telegram] Failed to send admin response:", err));
                logger?.info("\u2705 [Telegram] Admin data sent");
                return c.text("OK", 200);
              }
              if (messageText === "/clear") {
                clearAllApplications();
                telegramSendMessageTool.execute({
                  context: {
                    chat_id: chatId,
                    text: `\u2705 *\u0414\u0410\u041D\u041D\u042B\u0415 \u041E\u0427\u0418\u0429\u0415\u041D\u042B*

\u0412\u0441\u0435 \u0437\u0430\u044F\u0432\u043A\u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u044B \u0438\u0437 \u0431\u0430\u0437\u044B \u0434\u0430\u043D\u043D\u044B\u0445.`,
                    parse_mode: "Markdown"
                  },
                  mastra,
                  runtimeContext: {}
                }).catch((err) => logger?.error("\u274C [Telegram] Failed to send clear confirmation:", err));
                logger?.info("\u2705 [Telegram] All applications cleared");
                return c.text("OK", 200);
              }
            }
            if (messageText === "/start") {
              logger?.info("\u26A1 [Telegram] Fast-path /start command");
              telegramSendMessageTool.execute({
                context: {
                  chat_id: chatId,
                  text: MAIN_MENU_TEXT,
                  parse_mode: "Markdown",
                  reply_markup: {
                    inline_keyboard: [
                      [{ text: "\u{1F4AA} \u041F\u0440\u043E \u0441\u043F\u043E\u0440\u0442 \u043F\u0438\u0442\u0430\u043D\u0438\u0435", callback_data: "nutrition_video" }],
                      [{ text: "\u{1F3C6} \u041F\u043E\u0434 \u043A\u043B\u044E\u0447 \u0441 \u0418\u0441\u043B\u0430\u043C\u043E\u043C", callback_data: "coaching_video" }],
                      [{ text: "\u{1F4CB} \u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443", callback_data: "start_application" }]
                    ]
                  }
                },
                mastra,
                runtimeContext: {}
              }).catch((err) => logger?.error("\u274C [Telegram] Failed to send start message:", err));
              logger?.info("\u2705 [Telegram] Fast-path /start sent");
              return c.text("OK", 200);
            }
            if (hasApplication(chatId.toString()) && messageText && messageText !== "/start") {
              logger?.info("\u26A1 [Telegram] Fast-path application answer");
              const userApp = getApplication(chatId.toString());
              if (userApp) {
                const questions = [
                  `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 2/6:

\u0420\u043E\u0441\u0442 \u0438 \u0432\u0435\u0441?

*\u041F\u0440\u0438\u043C\u0435\u0440:* 180 \u0441\u043C 75 \u043A\u0433`,
                  `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 3/6:

\u0423 \u0442\u0435\u0431\u044F \u0435\u0441\u0442\u044C \u0437\u0430\u0431\u043E\u043B\u0435\u0432\u0430\u043D\u0438\u044F, \u0442\u0440\u0430\u0432\u043C\u044B, \u0430\u043B\u043B\u0435\u0440\u0433\u0438\u0438 \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u043D\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438?

*\u0415\u0441\u043B\u0438 \u043D\u0435\u0442, \u043D\u0430\u043F\u0438\u0448\u0438 "\u041D\u0435\u0442"*`,
                  `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 4/6:

\u0423 \u0442\u0435\u0431\u044F \u0435\u0441\u0442\u044C \u0446\u0435\u043B\u0438 \u0438 \u0437\u0430\u0434\u0430\u0447\u0438 \u043D\u0430 \u0442\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u043E\u0447\u043D\u044B\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441?

*\u041F\u0440\u0438\u043C\u0435\u0440:* \u043D\u0430\u0431\u043E\u0440 \u043C\u0430\u0441\u0441\u044B, \u0441\u043A\u0438\u043D\u0443\u0442\u044C \u0432\u0435\u0441, \u0440\u0435\u043B\u044C\u0435\u0444`,
                  `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 5/6:

\u041F\u043B\u0430\u043D\u0438\u0440\u0443\u0435\u0442\u0435 \u043B\u0438 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C \u0444\u0430\u0440\u043C\u0430\u043A\u043E\u043B\u043E\u0433\u0438\u044E, SARMS?

*\u0414\u0430/\u041D\u0435\u0442*`,
                  `\u{1F4DD} *\u0410\u041D\u041A\u0415\u0422\u0410 \u0414\u041B\u042F \u0422\u0420\u0415\u041D\u0418\u0420\u041E\u0412\u041E\u041A*

\u0412\u043E\u043F\u0440\u043E\u0441 6/6:

\u0415\u0441\u043B\u0438 \u0434\u0430, \u0442\u043E \u043A\u0430\u043A\u0438\u0435 \u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u044B \u0438 \u0434\u043E\u0437\u0438\u0440\u043E\u0432\u043A\u0438?

*\u0415\u0441\u043B\u0438 \u043D\u0435\u0442, \u043D\u0430\u043F\u0438\u0448\u0438 "\u041D\u0435\u0442"*`
                ];
                const answerKeys = ["nameAge", "heightWeight", "health", "goals", "plansPharmacology", "currentPharmacology"];
                if (userApp.step <= 5) {
                  userApp.answers[answerKeys[userApp.step - 1]] = messageText;
                  userApp.step++;
                  telegramSendMessageTool.execute({
                    context: {
                      chat_id: chatId,
                      text: questions[userApp.step - 2],
                      parse_mode: "Markdown",
                      reply_markup: {
                        inline_keyboard: [
                          [{ text: "\u274C \u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443", callback_data: "cancel_application" }]
                        ]
                      }
                    },
                    mastra,
                    runtimeContext: {}
                  }).then((result) => {
                    const messageIds = userApp.messageIds || [];
                    if (result.message_id) {
                      messageIds.push(result.message_id);
                    }
                    setApplication(chatId.toString(), {
                      step: userApp.step,
                      answers: userApp.answers,
                      createdAt: userApp.createdAt,
                      messageIds
                    });
                  }).catch((err) => logger?.error("\u274C [Telegram] Failed to send question:", err));
                  logger?.info("\u2705 [Telegram] Fast-path question sent");
                  return c.text("OK", 200);
                }
              }
            }
            triggerInfo = {
              type: "telegram/message",
              params: {
                userName: payload.message.from?.username || "unknown",
                message: payload.message.text || "",
                chatId: payload.message.chat.id
              },
              payload
            };
          } else {
            logger?.warn("\u26A0\uFE0F [Telegram] Unknown payload type, ignoring");
            return c.text("OK", 200);
          }
          await handler(mastra, triggerInfo);
          return c.text("OK", 200);
        } catch (error) {
          logger?.error("\u274C [Telegram] Error handling webhook:", error);
          return c.text("Internal Server Error", 500);
        }
      }
    })
  ];
}

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
const mastra = new Mastra({
  // Storage disabled - not needed for simple menu bot
  // storage: sharedPostgresStorage,
  // Register your workflows here
  workflows: {
    fitnessWorkflow
  },
  // Register your agents here
  agents: {},
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {}
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // ======================================================================
      // Static Assets Endpoint
      // ======================================================================
      {
        path: "/assets/main_menu_photo.jpg",
        method: "GET",
        createHandler: async ({
          mastra: mastra2
        }) => {
          return async (c) => {
            const logger = mastra2.getLogger();
            logger?.debug("[Static Asset] Serving main menu photo");
            try {
              const fs = await import('fs/promises');
              const path = await import('path');
              const photoPath = path.join(process.cwd(), "attached_assets", "main_menu_photo.jpg");
              const photoBuffer = await fs.readFile(photoPath);
              return c.body(photoBuffer, 200, {
                "Content-Type": "image/jpeg",
                "Cache-Control": "public, max-age=31536000"
              });
            } catch (error) {
              logger?.error("[Static Asset] Error serving photo:", error);
              return c.text("Photo not found", 404);
            }
          };
        }
      },
      // ======================================================================
      // Inngest Integration Endpoint
      // ======================================================================
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
      },
      // ======================================================================
      // Connector Webhook Triggers
      // ======================================================================
      // Add more connector triggers below using the same pattern
      // ...registerGithubTrigger({ ... }),
      // ...registerSlackTrigger({ ... }),
      // ...registerStripeWebhook({ ... }),
      // Telegram Fitness Bot Trigger
      ...registerTelegramTrigger({
        triggerType: "telegram/message",
        handler: async (mastra2, triggerInfo) => {
          const logger = mastra2.getLogger();
          logger?.info("\u{1F3AF} [Telegram Trigger] Processing message", {
            userName: triggerInfo.params.userName,
            chatId: triggerInfo.params.chatId,
            hasCallback: !!triggerInfo.params.callbackData
          });
          const threadId = `telegram-fitness-${triggerInfo.params.chatId}`;
          const run = await fitnessWorkflow.createRunAsync();
          await run.start({
            inputData: {
              threadId,
              chatId: triggerInfo.params.chatId,
              messageId: triggerInfo.params.messageId,
              messageText: triggerInfo.params.message,
              callbackData: triggerInfo.params.callbackData,
              callbackQueryId: triggerInfo.params.callbackQueryId,
              userName: triggerInfo.params.userName
            }
          });
        }
      })
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}

export { mastra };
